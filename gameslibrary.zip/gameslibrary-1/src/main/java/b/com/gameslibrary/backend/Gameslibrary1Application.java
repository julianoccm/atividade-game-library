package b.com.gameslibrary.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Gameslibrary1Application {

	public static void main(String[] args) {
		SpringApplication.run(Gameslibrary1Application.class, args);
	}

}
