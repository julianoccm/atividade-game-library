package b.com.gameslibrary.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Gameslibrary1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
